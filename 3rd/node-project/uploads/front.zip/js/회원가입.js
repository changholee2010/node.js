document.querySelector('button[type="submit"]').addEventListener('click', function (e) {
  e.preventDefault(); //이동하지 않기

  let userId = document.querySelector('#user-id').value;
  let userPwd1 = document.querySelector('#user-pw1').value;
  let userPwd2 = document.querySelector('#user-pw2').value;

  //아이디 4자리 이상 15자리 이하, 메세지
  if (userId.length < 4 || userId.length > 15) {
    alert('아이디의 길이는 4자리 이상 15자리 이하로 만들어 주세요');
    document.querySelector('#user-id').value = '';
    document.querySelector('#user-id').focus();
    return;
  }
  // 비밀번호 8자리 이상, 메세지, 초기화, focus
  if (userPwd1.length < 8) {
    alert('비밀번호 8자리 이상으로 만들어 주세요');
    document.querySelector('#user-pw1').value = '';
    document.querySelector('#user-pw1').focus();
    return;
  }
  // 비밀번호 일치확인, 메세지, 초기화, focus
  if (userPwd1 != userPwd2) {
    alert('비밀번호가 일치하지 않습니다');
    document.querySelector('#user-pw2').value = '';
    document.querySelector('#user-pw2').focus();
    return;
  }

  alert('문제없음');
});