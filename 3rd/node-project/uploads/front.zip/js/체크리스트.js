let ul = document.createElement("ul");
const ary = [];
document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  //빈 값인지 확인
  if (document.querySelector("#item").value == "") {
    alert("값을 입력하세요");
    return;
  }

  // 중복확인 후 배열에 넣기
  if (!ary.includes(document.querySelector("#item").value)) {
    ary.push(document.querySelector("#item").value);
    console.log(ary);
  } else {
    alert("중복된 항목입니다");
    document.querySelector("#item").value = "";
    document.querySelector("#item").focus();
    return;
  }

  // 화면에 내용 보이기
  let li = document.createElement("li");
  li.innerHTML = document.querySelector("#item").value;
  let span = document.createElement("span");
  span.innerHTML = "X";
  span.setAttribute("class", "close");
  li.appendChild(span);
  ul.appendChild(li);
  document.querySelector("#itemList").appendChild(ul);

  document.querySelector("#item").value = "";
  document.querySelector("#item").focus();
});

// X눌러 목록에서 제거, 배열에서 제거
document.querySelector("#itemList").addEventListener("click", function (e) {
  let che = ary.indexOf(e.target.parentElement.firstChild.textContent);
  if (e.target.className == "close") {
    ary.splice(che, 1);
    e.target.parentElement.remove();
  }
  console.log(ary);
});
